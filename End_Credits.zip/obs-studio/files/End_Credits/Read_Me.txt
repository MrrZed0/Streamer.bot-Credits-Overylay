Add Browser To OBS Source And Select Local File, Choose The index.html File Inside This Folder And Done. 
Setup Streamer.bot or FireBot To Write Username of each user into the text file for the credits to show.


Features:
- If The Text Files Are Empty It Wont Display That Category
- Auto Update Each Category Every time The Credits Finish
- 100% Local & Free